<br><br>
<div class=" text-secondary bg-light">
  <hr>
  <div class="" align="center">
    <div class="col-6">
      Copyright © 2021 UFPS - Todos los Derechos Reservados
      <br>
      Desarrollado por: YERSON CARMONA- CAMILO BOTELLO- JESUS SUAREZ
      <br>
      Versión: 1.0
      <br>
    </div>
    <div class="col-6">
      <a href="https://ingsistemas.cloud.ufps.edu.co/" target="_blank" class="">
        <img src="../imagenes/logo_vertical_ingsistemas.png" height="50">
      </a>
      <a href="https://ww2.ufps.edu.co/" target="_blank" class="col-4">
        <img src="../imagenes/logo_ufps.png" height="40">
      </a>
    </div>
    <br>
  </div>
</div>
