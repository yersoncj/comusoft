$('#detalle-tema a').on('click', function (e) {
  e.preventDefault()
  $(this).tab('show')
})
